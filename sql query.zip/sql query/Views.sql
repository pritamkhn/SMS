create table Pritam_Test
(
 Emp_ID int identity,
 Emp_Name varchar(55),
 Emp_Technology varchar(55),
 Emp_Sal decimal (10,2),
 Emp_Designation varchar(20)
)

Insert into Pritam_Test values ('Rahul','PHP',12000,'SE');
Insert into Pritam_Test values ('Sidd','ASP.NET',15000,'TL');
Insert into Pritam_Test values ('Riya','C#',14000,'SE');
Insert into Pritam_Test values ('Priya','JAVA',22000,'SSE');
Insert into Pritam_Test values ('Rucha','VB',18000,'TH');

-- View been created on the table
alter VIEW vw_Pritam_Test with schemabinding
AS
Select top 2 Emp_ID ,Emp_Name ,Emp_Designation
From sqluser.Pritam_Test 
where Emp_Designation='SE'
order by Emp_Name 




 -- Query view like as table
Select * from vw_Pritam_Test 
select * from Pritam_Test
SELECT * FROM [sqluser].[vw_Pritam_Test]




-- Inserting data into table from View
insert into vw_Pritam_Test(Emp_Name, Emp_Designation)
values ('Seema','SSE')



-- Now see the affected view
Select * from vw_Pritam_Test 



-- Update data to view vw_Pritam_Test
Update vw_Pritam_Test set Emp_Designation = 'Training' 
where Emp_ID = 3



-- Now see the affected view
Select * from vw_Pritam_Test 

-- Delete data from view vw_Pritam_Test
delete from vw_Pritam_Test where Emp_ID = 6



-- Now see the affected view
Select * from vw_Pritam_Test 

/* Creating a View from Joining Two Tables */

create table Personal_Pritam
(
 Emp_Name varchar(55),
 FName varchar(55),
 DOB varchar(55),
 Address varchar(55),
 Mobile int,
 State varchar(55)
)
-- Now Insert data

Insert into Personal_Pritam values ('Rahul','A','22-10-1985','Ghaziabad',96548922,'UP');
Insert into Personal_Pritam values ('Sidd','B','02-07-1986','Haridwar',96548200,'UK');
Insert into Personal_Pritam values ('Riya','C','30-04-1987','Noida',97437821,'UP');
Insert into Personal_Pritam values ('Priya','D','20-07-1986','Rampur',80109747,'UP');
Insert into Personal_Pritam values ('Rucha','E','21-10-1985','Delhi',96547954,'Delhi');

-- Now create view on two tables Pritam_Test and Personal_Pritam

Create VIEW vw_Employee_Personal_Pritam
As
Select e.Emp_ID, e.Emp_Name,e.Emp_Designation,p.DOB,
p.Mobile
From Pritam_Test e INNER JOIN Personal_Pritam p
On e.Emp_Name = p. Emp_Name






-- Now Query view like as table
Select * from vw_Employee_Personal_Pritam





--Update view 
update vw_Employee_Personal_Pritam 
set Emp_Designation = 'SSE' where Emp_ID = 3 




-- Now Query view like as table
Select * from vw_Employee_Personal_Pritam

delete from vw_Employee_Personal_Pritam where Emp_ID = 5