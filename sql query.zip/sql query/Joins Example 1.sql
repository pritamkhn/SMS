--Create Two Tables EmployeeDetails and EmpSalary
CREATE TABLE EmployeeDetails (
  EmpId int PRIMARY KEY,
  EmpFirstName varchar(50),
  EmpLastName varchar(50),
  Department varchar(50),
  DepartID int
)

CREATE TABLE EmpSalary (
  EmpID int,
  EmpFullName varchar(80),
  EmpSalary int,
  EmpWorkingYears int
)
        

--Insert data into EmployeeDetails
INSERT INTO EmployeeDetails
      VALUES (1001, 'Bhavana', 'Sharma', 'IT', 2)
    INSERT INTO EmployeeDetails
      VALUES (1002, 'Varun', 'Sharma', 'IT', 2)
    INSERT INTO EmployeeDetails
      VALUES (1003, 'Jaspreet', 'Kaur', 'Accounts', 3)
    INSERT INTO EmployeeDetails
      VALUES (1004, 'Shruti', 'Kalia', 'HR', 1)
    INSERT INTO EmployeeDetails
      VALUES (1005, 'Shaili', 'Verghese', 'IT', 2)
    INSERT INTO EmployeeDetails
      VALUES (1006, 'Rakesh', 'Dubey', 'Accounts', 3)
	INSERT INTO EmployeeDetails (EmpId,EmpFirstName,EmpLastName,Department)
      VALUES (1007, 'Priyanka', 'Sharma', 'Training')
	    INSERT INTO EmployeeDetails (EmpId,EmpFirstName,EmpLastName,Department)
      VALUES (1008, 'Sahil', 'Verma', 'Training')

--Insert Data into EmpSalary

INSERT INTO EmpSalary
        VALUES (1001, 'Bhavana Sharma', 35000, 3)
    INSERT INTO EmpSalary
      VALUES (1002, 'Varun Sharma', 25000, 2)
    INSERT INTO EmpSalary
      VALUES (1003, 'Jaspreet Kaur', 20000, 2)
    INSERT INTO EmpSalary
      VALUES (1004, 'Shruti Kalia', 18000, 1)
    INSERT INTO EmpSalary
      VALUES (1005, 'Shaili Verghese', 25000, 2)
    INSERT INTO EmpSalary (EmpFullName, EmpSalary, EmpWorkingYears)
      VALUES ('Ramesh Kumar', 6000, 1)
	 INSERT INTO EmpSalary (EmpFullName, EmpSalary, EmpWorkingYears)
      VALUES ('Mahesh Kumar', 8000, 1)


--Select Details from EmpDetails
SELECT  * FROM EmployeeDetails

--Select Data from EmpSalary
SELECT  * FROM EmpSalary

--Innser Join
 SELECT
        EmployeeDetails.EmpId,
        EmployeeDetails.EmpFirstName,
        EmpSalary.EmpSalary
    FROM EmployeeDetails
    JOIN EmpSalary
        ON EmployeeDetails.EmpId = EmpSalary.EmpID


--LEFT OUTER JOIN
SELECT
        e.EmpId,
        e.EmpFirstName,
        e.DepartID,
        s.EmpSalary
    FROM EmployeeDetails e
    LEFT OUTER JOIN EmpSalary s
        ON e.EmpId = s.EmpID


--Right Outer Join
SELECT
        e.EmpId,
        e.EmpFirstName,
        e.DepartID,
        s.EmpSalary
    FROM EmployeeDetails e
    RIGHT OUTER JOIN EmpSalary s
        ON e.EmpId = s.EmpID


--Full Outer Join
SELECT
      e.EmpId,
      e.EmpFirstName,
      e.DepartID,
      s.EmpSalary
    FROM EmployeeDetails e
    FULL OUTER JOIN EmpSalary s
      ON e.EmpId = s.EmpID


--EQUI JOIN
/*An Equi Join is same as inner join , it joins the tables with the help of a foreign key. 
However an equi join differs from inner join in only one way, an equi join display all the column
from both the tables.
*/

SELECT *
    FROM EmployeeDetails JOIN EmpSalary
    ON EmployeeDetails.EmpId = EmpSalary.EmpID



--SELF JOIN

ALTER TABLE EmployeeDetails
ADD ManagerID int

UPDATE EmployeeDetails
SET ManagerID = 1002
WHERE empid = 1001
UPDATE EmployeeDetails
SET ManagerID = 1002
WHERE empid = 1005
UPDATE EmployeeDetails
SET ManagerID = 1006
WHERE empid = 1003
UPDATE EmployeeDetails
SET ManagerID = 1004
WHERE empid = 1007
UPDATE EmployeeDetails
SET ManagerID = 1004
WHERE empid = 1008

SELECT
  *
FROM EmployeeDetails


--Self Join to get Manager ID
SELECT a.EmpId, a.EmpFirstName AS ManagerName,
    b.EmpId AS ManagerID,b.EmpFirstName AS EmployeeName
    FROM EmployeeDetails a , EmployeeDetails b
    WHERE a.EmpId = b.ManagerID


--CROSS JOIN
/*
The Cross Join can also be called as Cartesian Product of the two tables. 
The result would be the number of rows in the 
first table multiplied by the number of rows in the second table.

If you have 4 rows in first table and 3 rows in second table, 
you will get 12 rows when you have cross join on both table.
*/
--Create Base Computer Table
CREATE TABLE Computer (
      CompID int,
      computerDes varchar(100),
      Price int
  )

  INSERT INTO computer
    VALUES (1, 'Pentium 4,1GB RAM', 25000)
  INSERT INTO computer
    VALUES (2, 'Dual Core,2GB RAM', 35000) 



--Create Add-On Table
CREATE TABLE Addon (
      ID INT,
      Description VARCHAR(100),
      Price INT
   )     

   INSERT INTO Addon
      VALUES (1, 'Speakers', 5000)
   INSERT INTO Addon
      VALUES (2, 'printer', 15000)


--You will use CROSS JOIN which to get computer and additional product price.

   SELECT
    computer.computerDes,
    Addon.description,
    computer.Price + Addon.price AS totalprice
  FROM Computer
    CROSS JOIN Addon