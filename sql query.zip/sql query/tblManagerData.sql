create table tblManagerPritamData (
	ManagerID INT PRIMARY KEY,
	first_name VARCHAR(50),
	last_name VARCHAR(50)
);
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (1, 'Alyssa', 'Paling');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (2, 'Flossy', 'Frackiewicz');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (3, 'Laird', 'Macias');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (4, 'Nahum', 'Huke');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (5, 'Grata', 'Brash');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (6, 'Tiffany', 'Peirone');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (7, 'Jacenta', 'Heakins');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (8, 'Berne', 'Dionis');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (9, 'Monroe', 'Screas');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (10, 'Bambi', 'Stockill');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (11, 'Ernaline', 'Dahle');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (12, 'Horace', 'Spowart');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (13, 'Luciana', 'Skyrm');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (14, 'Josefa', 'Tamsett');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (15, 'Myron', 'Burel');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (16, 'Morly', 'Baynton');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (17, 'Wendeline', 'Dumbreck');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (18, 'Marlowe', 'Gabala');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (19, 'Marita', 'Loving');
insert into tblManagerPritamData (ManagerID, first_name, last_name) values (20, 'Charmane', 'Switsur');
