-- SERIALIZABLE READ (Session 3)
-- Insert into a SERIALIZABLE Read Isolation Level
insert into [dbo].[Company_Details]
values(23001,'NewCompany1','01/01/2014','Rahul1','Joshi1')