-- SERIALIZABLE READ (Session 1)
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE 
BEGIN TRAN;
SELECT id,companyname,dateofjoining,username,password
FROM [dbo].[Company_Details]
WHERE id > 100




commit