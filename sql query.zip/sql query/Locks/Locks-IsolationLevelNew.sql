Create Database LockDB

use LockDB
CREATE TABLE dbo.TestIsolationLevels (
EmpID INT NOT NULL,
EmpName VARCHAR(100),
EmpSalary MONEY,
CONSTRAINT pk_EmpID PRIMARY KEY(EmpID) )
GO

INSERT INTO dbo.TestIsolationLevels 
VALUES 
(2322, 'Dave Smith', 35000),
(2900, 'John West', 22000),
(2219, 'Melinda Carlisle', 40000),
(2950, 'Adam Johns', 18000) 
GO

EXAMPLE 1 - STARTS

-- Read using READ Committed
-- Session 1
BEGIN TRAN
UPDATE  dbo.TestIsolationLevels 
SET     EmpSalary = 25000
WHERE   EmpID = 2900

-- Session 2
SELECT EmpID, EmpName, EmpSalary
FROM dbo.TestIsolationLevels
WHERE EmpID = 2900

-- EXAMPLE 1 - ENDS


-- EXAMPLE 2 - STARTS
-- SESSION 1

BEGIN TRAN
UPDATE  dbo.TestIsolationLevels 
SET     EmpSalary = 25000
WHERE   EmpID = 2900

-- SESSION 2
-- Read using READ UNCOMMITTED

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON
GO
SELECT EmpID, EmpName, EmpSalary
FROM dbo.TestIsolationLevels
WHERE EmpID = 2900

-- EXAMPLE 2 ENDS


-- EXAMPLE 3
-- SESSION 1
-- MAKE SURE ALL THE CONNNECTIONS TO THE DATABASE LOCKDB ARE CLOSED, AS WE WILL BE ISSUING ALTER
-- DATABASE COMMAND AND IF ANY SESSION IS OPEN THEN THE ALTER DATABASE COMMAND GOES IN HUNG STATE

ALTER DATABASE LockDB SET READ_COMMITTED_SNAPSHOT ON
GO
BEGIN TRAN
UPDATE  dbo.TestIsolationLevels 
SET     EmpSalary = 25000
WHERE   EmpID = 2900

-- SESSION 2
SELECT EmpID, EmpName, EmpSalary
FROM dbo.TestIsolationLevels
WHERE EmpID = 2900



