-- REPEATABLE READ (Session 2)
UPDATE [dbo].[Company_Details]
set companyname = 'Flairedge'
WHERE id = 3

delete [dbo].[Company_Details]
where id = 3