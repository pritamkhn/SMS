-- REPEATABLE READ (Session 1)
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
BEGIN TRAN;
SELECT id,companyname,dateofjoining,username,password
FROM [dbo].[Company_Details]
WHERE id = 3




commit