
-- Insert into a Repeatable Read Isolation Level
insert into [dbo].[Company_Details]
values(3,'NewCompany','01/01/2014','Rahul','Joshi')