create table Pritam_Details (
	id INT,
	CompanyName VARCHAR(50),
	DateOfJoining DATE,
	username VARCHAR(50),
	Password VARCHAR(50)
);
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (1, 'Wikibox', '2/3/2011', 'jcastillo0', 'm6plizn7f');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (2, 'Meezzy', '8/6/2011', 'kramirez1', 'eWsj4DFXT');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (3, 'Photolist', '1/6/2013', 'jray2', 'gzdEhR8IXOq');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (4, 'Tagopia', '3/28/2011', 'dmiller3', '9xODrXe2');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (5, 'Minyx', '11/3/2010', 'rgray4', 'zwjhiskPmzfj');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (6, 'Livetube', '9/23/2013', 'kbell5', '0Z8VD9aI');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (7, 'Feedfire', '1/15/2014', 'lcruz6', 'sRyamx');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (8, 'Feedfire', '9/15/2011', 'sarmstrong7', 'PHAadOCDeD');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (9, 'Aimbu', '7/17/2012', 'fellis8', 'Lb7lJCCVGo');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (10, 'Zoomlounge', '7/8/2013', 'elawson9', '56CP3zlb');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (11, 'Jaloo', '3/2/2013', 'lkima', 'so0yez4B40Jp');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (12, 'Edgepulse', '1/14/2013', 'rwalkerb', 'kXIzHM2');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (13, 'Zoombeat', '4/17/2013', 'wdanielsc', 'iHYwoTikNFI');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (14, 'Ntag', '7/15/2013', 'larnoldd', 'IJIU3RkW2');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (15, 'Skynoodle', '11/4/2012', 'tolsone', 'Z4gkHuCLD');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (16, 'Tagcat', '1/13/2013', 'jjenkinsf', 'HpgP6H');
insert into Pritam_Details (id, CompanyName, DateOfJoining, username, Password) values (17, 'Voonix', '1/27/2013', 'nkimg', 'G1hkK72KaDN');

select * from Pritam_Details