﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SchoolManagementSystem.Models;

namespace SchoolManagementSystem.Controllers
{
    public class TeachersController : Controller
    {
        private Entities db = new Entities();

        // GET: Teachers
        public ActionResult Index()
        {
            return View(db.Teachers.ToList());
        }

        // GET: Teachers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var teacher = (from t in db.Teachers
                              where t.Teacher_Id == id
                              select t).SingleOrDefault();
           // Teacher teacher = db.Teachers.Find(id);
            if (teacher == null)
            {
                return HttpNotFound();
            }
            return View(teacher);
        }

        // GET: Teachers/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Teachers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Name,Gender,DOB,Blood_Group,Contact,Email,Address,Teacher_Id")] Teacher teacher)
        {
            if (ModelState.IsValid)
            {
                db.Teachers.Add(teacher);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(teacher);
        }

        // GET: Teachers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Teacher teacher = db.Teachers.Find(id);
            if (teacher == null)
            {
                return HttpNotFound();
            }
            return View(teacher);
        }

        // POST: Teachers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Name,Gender,DOB,Blood_Group,Contact,Email,Address,Teacher_Id")] Teacher teacher)
        {
            if (ModelState.IsValid)
            {
                var tea = db.Teachers.SingleOrDefault(e => e.Teacher_Id == teacher.Teacher_Id);
                if (tea != null)
                {
                    tea.Name = teacher.Name;
                    tea.DOB = teacher.DOB;
                    tea.Gender = teacher.Gender;
                    tea.Email = teacher.Email;
                    tea.Contact = teacher.Contact;
                    tea.Blood_Group = teacher.Blood_Group;
                    tea.Address = teacher.Address;
                    // dbEmp.Entry(employee).State = EntityState.Modified;
                    db.SaveChanges();
                }
                //db.Entry(teacher).State = EntityState.Modified;
                //db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(teacher);
        }

        // GET: Teachers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Teacher teacher = db.Teachers.Find(id);
            if (teacher == null)
            {
                return HttpNotFound();
            }
            return View(teacher);
        }

        // POST: Teachers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            // Teacher teacher = db.Teachers.Find(id);
            var teacher = db.Teachers.SingleOrDefault(e => e.Teacher_Id == id);
            if (teacher == null)
            {
                return HttpNotFound();
            }
            db.Teachers.Remove(teacher);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
